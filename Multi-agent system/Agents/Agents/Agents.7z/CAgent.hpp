#ifndef AGENT_HPP_
#define AGENT_HPP_

#define DWORD64 long long

class �Agent
{
public:
	�Agent();
	~�Agent();

private:

};

�Agent::�Agent()
{
}

�Agent::~�Agent()
{
}

#endif